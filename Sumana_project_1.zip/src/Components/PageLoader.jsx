import React from 'react'

const PageLoader = () => {
    return (
        <>

            <div id="spinner" class="show position-fixed translate-middle w-100 vh-100 top-50 start-50 d-flex align-items-center justify-content-center">
                <div class="spinner-grow text-primary" role="status"></div>
            </div>

        </>
    )
}

export default PageLoader